#what every user is going to naviagte code in this file

from flask import Blueprint, render_template, request, Flask , flash, redirect, url_for
from .models import User
from werkzeug.security import generate_password_hash, check_password_hash
from . import db # to get the db object from __init__ into this auth.py

from flask_login import login_user, login_required, logout_user, current_user

auth = Blueprint('auth', __name__)
#login logout signup

@auth.route('/login', methods = ['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email = email).first()
        if user:
            if check_password_hash(user.password, password):
                flash('Logged in successfully!', category='success')
                login_user(user, remember= True)    #if web server is running you are login or if you havent clear the data
                return redirect(url_for('views.home'))
            else:
                flash('Incorrect password, try again.', category='error')
        else:
            flash("Email does not exist.", category='error')
    data = request.form
    print(data)
    return render_template("login.html", user =current_user)

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))    

@auth.route('/signup', methods = ['GET', 'POST'] )
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name1 = request.form.get('FirstName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter_by(email = email).first()
        if user:
            flash('Email already exists.', category='error')    
        elif len(email) <4:
            flash('too short email, eneter email whos length is more than 4', category= 'error')
        elif len(first_name1) <2:
            flash('Name len should be more then or equal to 2', category= 'error')
        elif password1 != password2:
            flash('passowrd mismatch', category= 'error')
        elif len(password1)<7:
            flash('password length should be more than 7', category= 'error')
        else:
            new_user = User(email = email,first_name = first_name1, password = generate_password_hash(
                password1, method='pbkdf2:sha256'))
            db.session.add(new_user)
            db.session.commit()

            login_user(user, remember= True)        #this

            flash('Account created', category= 'success' )
                                    #blueprint_name.Function_name 
            return redirect(url_for('views.home'))

            #add user to database
            #pass
    return render_template("signup.html", user = current_user )

