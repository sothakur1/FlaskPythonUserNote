function deleteNote(noteID1){
    fetch("/delete-note",{
      method: "POST",
      body: JSON.stringify({ noteID: noteID1})
    }).then((_res) => {
      window.location.href = "/";  //once we hit delete-note api and do the functioning,
                                // then _res will do that it will redirect you to the home page with updated contnet  
    });
 }

