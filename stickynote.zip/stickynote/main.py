from website import create_app

app = create_app()

if __name__ == '__main__':      #entry point
    app.run(debug = True)  #its going to run our web server